package com.unir.roleapp.adventure.domain.model

data class CharacterContext(
    val characterId: String,
    val context: String
)