package com.unir.roleapp.character.data.model.local

data class AttributeModifiers(
    val type: StatName,
    var modifyingValue: Int = 0
)