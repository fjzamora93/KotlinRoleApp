package com.unir.roleapp.adventure.domain.model

data class Character(
    val id: Long,
    val name: String
)