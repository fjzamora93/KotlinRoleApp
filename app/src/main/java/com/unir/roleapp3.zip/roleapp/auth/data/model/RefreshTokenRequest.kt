package com.roleapp.auth.data.model

data class RefreshTokenRequest(
    val refreshToken: String
)