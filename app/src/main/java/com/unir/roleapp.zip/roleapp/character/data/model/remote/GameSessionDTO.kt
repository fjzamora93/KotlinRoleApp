package com.roleapp.character.data.model.remote

data class GameSessionDTO(
    private val id: Int,
    private val userId: Int,
)
