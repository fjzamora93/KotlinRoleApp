package com.unir.roleapp.adventure.data.model

//! NO TENER EN CUENTA -> UTILIZAR LO DE PABLO
data class GameSession(
    val id: Comparable<*>,
)
