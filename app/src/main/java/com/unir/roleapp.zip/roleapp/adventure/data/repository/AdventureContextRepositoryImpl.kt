package com.unir.roleapp.adventure.data.repository

import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.unir.roleapp.adventure.domain.model.CharacterContext
import com.unir.roleapp.adventure.domain.usecase.SaveAdventureContextUseCase
import kotlinx.coroutines.tasks.await
import javax.inject.Inject

class AdventureContextRepositoryImpl @Inject constructor() : SaveAdventureContextUseCase {
    private val db: FirebaseFirestore = Firebase.firestore

    override suspend fun invoke(
        adventureId: String,
        historicalContext: String,
        characterContexts: List<CharacterContext>
    ): Result<Unit> {
        return try {
            db.collection("adventures")
                .document(adventureId)
                .update(
                    "historicalContext",  historicalContext,
                    "characterContexts",  characterContexts
                )
                .await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}