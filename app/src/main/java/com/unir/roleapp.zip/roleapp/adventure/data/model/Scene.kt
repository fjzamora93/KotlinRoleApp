package com.unir.roleapp.adventure.data.model

// data class que representará una escena de la aventura
data class Scene(
    var name : String,
    var description : String,
)
