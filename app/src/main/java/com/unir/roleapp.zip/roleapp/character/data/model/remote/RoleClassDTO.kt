package com.roleapp.character.data.model.remote

class RoleClassDTO (
    val id: Int,
    val name: String,
    val spells: List<SpellDTO>
)