package com.roleapp.character.domain

object Constants {

    const val MY_DATA_BASE = "my-database"

}