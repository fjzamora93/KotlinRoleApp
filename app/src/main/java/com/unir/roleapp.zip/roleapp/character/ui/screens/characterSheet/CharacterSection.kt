package com.unir.roleapp.character.ui.screens.characterSheet

enum class CharacterSection {
    CHARACTERDETAIL, INVENTORY, SPELLS, SESSION

}