package com.unir.roleapp.adventure.ui.viewmodels

import dagger.hilt.android.lifecycle.HiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.unir.roleapp.adventure.domain.model.Adventure
import com.unir.roleapp.adventure.domain.usecase.CreateAdventureUseCase
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class CreateAdventureViewModel @Inject constructor(
    private val createGame: CreateAdventureUseCase
): ViewModel() {
    val title       = MutableStateFlow("")
    val description = MutableStateFlow("")

    private val _loading = MutableStateFlow(false)
    val loading: StateFlow<Boolean> = _loading

    private val _error   = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error

    fun onTitleChange(v: String)       = title.tryEmit(v)
    fun onDescriptionChange(v: String) = description.tryEmit(v)

    fun createAdventure(onSuccess: (Adventure) -> Unit) = viewModelScope.launch {
        _loading.value = true; _error.value = null
        createGame(title.value, description.value)
            .onSuccess { onSuccess(it) }
            .onFailure { _error.value = it.message }
        _loading.value = false
    }
}